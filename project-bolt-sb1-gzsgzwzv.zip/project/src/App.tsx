import React, { useState } from 'react';
import { ShoppingCart, User } from 'lucide-react';
import { products, getProductsByCategory, searchProducts } from './data/products';

// Components
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedProducts from './components/FeaturedProducts';
import ProductGrid from './components/ProductGrid';
import CartDrawer from './components/CartDrawer';
import AuthModal from './components/AuthModal';
import Footer from './components/Footer';

// Context providers
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [searchResults, setSearchResults] = useState(products);
  const [isSearching, setIsSearching] = useState(false);
  
  const vegetables = getProductsByCategory('vegetable');
  const greens = getProductsByCategory('greens');
  const seasonal = getProductsByCategory('seasonal');
  
  const handleSearch = (query: string) => {
    if (query.trim() === '') {
      setIsSearching(false);
      setSearchResults(products);
    } else {
      const results = searchProducts(query);
      setSearchResults(results);
      setIsSearching(true);
    }
  };
  
  return (
    <AuthProvider>
      <CartProvider>
        <div className="min-h-screen flex flex-col">
          {/* Floating cart and login buttons for mobile */}
          <div className="md:hidden fixed bottom-4 right-4 z-40 flex flex-col space-y-2">
            <button 
              onClick={() => setIsAuthModalOpen(true)} 
              className="bg-white text-green-600 p-3 rounded-full shadow-lg hover:bg-green-50 transition-colors"
              aria-label="Account"
            >
              <User size={24} />
            </button>
            <button 
              onClick={() => setIsCartOpen(true)} 
              className="bg-green-600 text-white p-3 rounded-full shadow-lg hover:bg-green-700 transition-colors"
              aria-label="Cart"
            >
              <ShoppingCart size={24} />
            </button>
          </div>
          
          {/* Navbar */}
          <Navbar onSearchSubmit={handleSearch} />
          
          {/* Main content */}
          <main className="flex-grow">
            {/* Only show hero if not searching */}
            {!isSearching && <Hero />}
            
            {/* Featured products if not searching */}
            {!isSearching && <FeaturedProducts />}
            
            {/* Product sections or search results */}
            {isSearching ? (
              <ProductGrid 
                products={searchResults} 
                title={`Search Results (${searchResults.length} products)`} 
              />
            ) : (
              <>
                <ProductGrid products={vegetables} title="Fresh Vegetables" id="vegetables" />
                <ProductGrid products={greens} title="Leafy Greens" id="greens" />
                <ProductGrid products={seasonal} title="Seasonal Products" id="seasonal" />
              </>
            )}
          </main>
          
          {/* Footer */}
          <Footer />
          
          {/* Modals */}
          <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
          <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
        </div>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;