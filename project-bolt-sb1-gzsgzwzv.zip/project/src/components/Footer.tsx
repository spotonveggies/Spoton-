import React from 'react';
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-green-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand and about */}
          <div>
            <a href="#" className="flex items-center mb-4">
              <span className="text-white font-bold text-2xl">Spot</span>
              <span className="text-orange-400 font-bold text-2xl">On</span>
            </a>
            <p className="text-green-200 mb-4">
              Delivering farm-fresh vegetables and greens directly to your doorstep. We believe in sustainable farming and supporting local farmers.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-orange-400 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-orange-400 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-orange-400 transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          {/* Quick links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-green-200 hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a href="#about" className="text-green-200 hover:text-white transition-colors">About Us</a>
              </li>
              <li>
                <a href="#vegetables" className="text-green-200 hover:text-white transition-colors">Vegetables</a>
              </li>
              <li>
                <a href="#greens" className="text-green-200 hover:text-white transition-colors">Greens</a>
              </li>
              <li>
                <a href="#seasonal" className="text-green-200 hover:text-white transition-colors">Seasonal Products</a>
              </li>
              <li>
                <a href="#blog" className="text-green-200 hover:text-white transition-colors">Blog</a>
              </li>
            </ul>
          </div>
          
          {/* Customer service */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li>
                <a href="#faq" className="text-green-200 hover:text-white transition-colors">FAQ</a>
              </li>
              <li>
                <a href="#shipping" className="text-green-200 hover:text-white transition-colors">Shipping Policy</a>
              </li>
              <li>
                <a href="#returns" className="text-green-200 hover:text-white transition-colors">Returns & Refunds</a>
              </li>
              <li>
                <a href="#privacy" className="text-green-200 hover:text-white transition-colors">Privacy Policy</a>
              </li>
              <li>
                <a href="#terms" className="text-green-200 hover:text-white transition-colors">Terms & Conditions</a>
              </li>
            </ul>
          </div>
          
          {/* Contact information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="text-orange-400 mr-2 mt-1 flex-shrink-0" />
                <span className="text-green-200"> 143 Thendral nagar Tiruvannamalai </span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="text-orange-400 mr-2 flex-shrink-0" />
                <span className="text-green-200">+91 7200942086</span>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="text-orange-400 mr-2 flex-shrink-0" />
                <span className="text-green-200">info@spotonveggies.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-green-700 mt-12 pt-8 text-center">
          <p className="text-green-200 text-sm">
            &copy; {new Date().getFullYear()} SpotOn Fresh Vegetables. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;