import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-r from-green-500 to-green-700 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="grid" width="8" height="8" patternUnits="userSpaceOnUse">
              <path d="M 8 0 L 0 0 0 8" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#grid)" />
        </svg>
      </div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-4">
              Farm Fresh <span className="text-yellow-300">Vegetables</span> Delivered to Your Door
            </h1>
            <p className="text-green-100 text-lg md:text-xl mb-8 max-w-lg">
              Experience the freshness of locally sourced organic produce, delivered from our farms to your table within 24 hours of harvest.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="#products" 
                className="bg-white text-green-700 hover:bg-green-50 px-6 py-3 rounded-full font-semibold flex items-center justify-center transition-colors duration-300"
              >
                Shop Now
                <ArrowRight size={18} className="ml-2" />
              </a>
              <a 
                href="#about" 
                className="bg-transparent hover:bg-green-600 border-2 border-white text-white px-6 py-3 rounded-full font-semibold flex items-center justify-center transition-colors duration-300"
              >
                Learn More
              </a>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="relative rounded-lg overflow-hidden shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500">
              <img 
                src="https://images.pexels.com/photos/1458694/pexels-photo-1458694.jpeg" 
                alt="Fresh vegetables" 
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent">
                <div className="absolute bottom-0 left-0 p-6">
                  <span className="inline-block bg-orange-500 text-white text-sm font-semibold px-3 py-1 rounded-full mb-2">
                    Limited Time
                  </span>
                  <h3 className="text-white text-xl font-bold">20% Off First Order</h3>
                </div>
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-white rounded-full p-4 shadow-lg hidden md:block">
              <img 
                src="https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg" 
                alt="Organic tomatoes" 
                className="w-20 h-20 object-cover rounded-full"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white rounded-full p-4 shadow-lg hidden md:block">
              <img 
                src="https://images.pexels.com/photos/65174/pexels-photo-65174.jpeg" 
                alt="Fresh greens" 
                className="w-16 h-16 object-cover rounded-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;