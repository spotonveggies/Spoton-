import React, { useState } from 'react';
import { Search, ShoppingCart, User, Menu, X } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onSearchSubmit: (query: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onSearchSubmit }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { totalItems } = useCart();
  const { isAuthenticated, user, logout } = useAuth();
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit(searchQuery);
  };
  
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <a href="#" className="flex items-center">
              <span className="text-green-600 font-bold text-2xl">Spot</span>
              <span className="text-orange-500 font-bold text-2xl">On</span>
            </a>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-green-600 px-3 py-2 text-sm font-medium transition-colors duration-200">
              Home
            </a>
            <a href="#vegetables" className="text-gray-700 hover:text-green-600 px-3 py-2 text-sm font-medium transition-colors duration-200">
              Vegetables
            </a>
            <a href="#greens" className="text-gray-700 hover:text-green-600 px-3 py-2 text-sm font-medium transition-colors duration-200">
              Greens
            </a>
            <a href="#seasonal" className="text-gray-700 hover:text-green-600 px-3 py-2 text-sm font-medium transition-colors duration-200">
              Seasonal
            </a>
          </nav>
          
          {/* Search, Cart, and User actions */}
          <div className="hidden md:flex items-center space-x-4">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="bg-gray-100 rounded-full py-1 px-4 pl-10 w-48 focus:outline-none focus:ring-2 focus:ring-green-500 focus:bg-white transition-all duration-200"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
            </form>
            
            <a href="#cart" className="relative p-1.5 rounded-full hover:bg-gray-100 transition-colors duration-200">
              <ShoppingCart size={22} className="text-gray-700" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </a>
            
            {isAuthenticated ? (
              <div className="relative group">
                <button className="flex items-center space-x-1 text-sm font-medium text-gray-700 hover:text-green-600">
                  <span>Hi, {user?.name.split(' ')[0]}</span>
                  <User size={20} />
                </button>
                <div className="absolute right-0 w-48 mt-2 origin-top-right bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <div className="py-1">
                    <a href="#profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Your Profile</a>
                    <a href="#orders" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Your Orders</a>
                    <button onClick={logout} className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      Sign out
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <a href="#login" className="text-sm font-medium text-gray-700 hover:text-green-600">
                Login / Register
              </a>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              type="button"
              className="p-1 rounded-md text-gray-700 hover:text-green-600 focus:outline-none"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#" className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-green-600">
              Home
            </a>
            <a href="#vegetables" className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-green-600">
              Vegetables
            </a>
            <a href="#greens" className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-green-600">
              Greens
            </a>
            <a href="#seasonal" className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-green-600">
              Seasonal
            </a>
          </div>
          
          <div className="pt-4 pb-3 border-t border-gray-200">
            <form onSubmit={handleSearchSubmit} className="px-4 mb-3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="bg-gray-100 rounded-full py-2 px-4 pl-10 w-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:bg-white"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
              </div>
            </form>
            
            <div className="flex items-center justify-between px-4">
              <a href="#cart" className="flex items-center space-x-2 text-base font-medium text-gray-700 hover:text-green-600">
                <ShoppingCart size={20} />
                <span>Cart ({totalItems})</span>
              </a>
              
              {isAuthenticated ? (
                <button onClick={logout} className="text-base font-medium text-gray-700 hover:text-green-600">
                  Sign out
                </button>
              ) : (
                <a href="#login" className="text-base font-medium text-gray-700 hover:text-green-600">
                  Login / Register
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;