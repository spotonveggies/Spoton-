import React from 'react';
import { Product } from '../data/products';
import { useCart } from '../context/CartContext';
import { ShoppingCart, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  
  return (
    <div className="group relative bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-xl">
      {/* Badge for organic products */}
      {product.isOrganic && (
        <div className="absolute top-2 left-2 z-10 bg-green-600 text-white text-xs font-semibold px-2 py-1 rounded-full">
          Organic
        </div>
      )}
      
      {/* Image container */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <button 
          className="absolute top-2 right-2 p-1.5 bg-white/80 hover:bg-white rounded-full text-gray-600 hover:text-red-500 transition-colors duration-300"
          aria-label="Add to favorites"
        >
          <Heart size={18} />
        </button>
      </div>
      
      {/* Content */}
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-1">{product.name}</h3>
        <p className="text-sm text-gray-500 mb-2">{product.unit}</p>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2" title={product.description}>
          {product.description}
        </p>
        
        <div className="flex items-center justify-between mt-auto">
          <span className="text-lg font-bold text-gray-900">₹{product.price}</span>
          <button
            onClick={() => addToCart(product)}
            className="flex items-center bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-md transition-colors duration-300"
          >
            <ShoppingCart size={16} className="mr-1" />
            <span>Add</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;