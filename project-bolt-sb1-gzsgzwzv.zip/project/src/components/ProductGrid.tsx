import React from 'react';
import ProductCard from './ProductCard';
import { Product } from '../data/products';

interface ProductGridProps {
  products: Product[];
  title: string;
  id?: string;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, title, id }) => {
  return (
    <section id={id} className="py-12">
      <div className="container mx-auto px-4">
        <div className="mb-10">
          <h2 className="text-3xl font-bold text-gray-800">{title}</h2>
          <div className="mt-2 w-20 h-1.5 bg-green-600 rounded-full"></div>
        </div>
        
        {products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No products found.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductGrid;