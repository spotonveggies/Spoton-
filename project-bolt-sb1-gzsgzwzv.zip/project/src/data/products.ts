export interface Product {
  id: string;
  name: string;
  category: 'vegetable' | 'greens' | 'seasonal' | 'organic';
  price: number;
  image: string;
  unit: string;
  description: string;
  inStock: boolean;
  isOrganic?: boolean;
  isFeatured?: boolean;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Fresh Spinach',
    category: 'greens',
    price: 30,
    image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg',
    unit: 'bunch',
    description: 'Locally sourced fresh spinach, rich in iron and vitamins.',
    inStock: true,
    isOrganic: true,
    isFeatured: true
  },
  {
    id: '2',
    name: 'Red Tomatoes',
    category: 'vegetable',
    price: 40,
    image: 'https://images.pexels.com/photos/1327838/pexels-photo-1327838.jpeg',
    unit: '500g',
    description: 'Ripe, juicy tomatoes perfect for salads and cooking.',
    inStock: true,
    isFeatured: true
  },
  {
    id: '3',
    name: 'Organic Carrots',
    category: 'vegetable',
    price: 35,
    image: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg',
    unit: '500g',
    description: 'Sweet and crunchy carrots grown without pesticides.',
    inStock: true,
    isOrganic: true
  },
  {
    id: '4',
    name: 'Green Capsicum',
    category: 'vegetable',
    price: 25,
    image: 'https://images.pexels.com/photos/594137/pexels-photo-594137.jpeg',
    unit: '250g',
    description: 'Crisp green bell peppers, great for stir-fries and salads.',
    inStock: true
  },
  {
    id: '5',
    name: 'Fresh Coriander',
    category: 'greens',
    price: 15,
    image: 'https://images.pexels.com/photos/606797/pexels-photo-606797.jpeg',
    unit: 'bunch',
    description: 'Aromatic herb that adds flavor to any dish.',
    inStock: true,
    isOrganic: true
  },
  {
    id: '6',
    name: 'Seasonal Mangoes',
    category: 'seasonal',
    price: 120,
    image: 'https://images.pexels.com/photos/918643/pexels-photo-918643.jpeg',
    unit: 'kg',
    description: 'Sweet and juicy Alphonso mangoes, available for a limited time.',
    inStock: true,
    isFeatured: true
  },
  {
    id: '7',
    name: 'Red Onions',
    category: 'vegetable',
    price: 30,
    image: 'https://images.pexels.com/photos/144206/pexels-photo-144206.jpeg',
    unit: 'kg',
    description: 'Essential cooking ingredient with a sharp, sweet flavor.',
    inStock: true
  },
  {
    id: '8',
    name: 'Baby Potatoes',
    category: 'vegetable',
    price: 45,
    image: 'https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg',
    unit: 'kg',
    description: 'Small, tender potatoes perfect for roasting.',
    inStock: true
  },
  {
    id: '9',
    name: 'Fresh Mint',
    category: 'greens',
    price: 20,
    image: 'https://images.pexels.com/photos/760281/pexels-photo-760281.jpeg',
    unit: 'bunch',
    description: 'Refreshing mint leaves for teas, drinks, and cooking.',
    inStock: true,
    isOrganic: true
  },
  {
    id: '10',
    name: 'Green Chillies',
    category: 'vegetable',
    price: 10,
    image: 'https://images.pexels.com/photos/3298064/pexels-photo-3298064.jpeg',
    unit: '100g',
    description: 'Spicy green chillies to add heat to your dishes.',
    inStock: true
  },
  {
    id: '11',
    name: 'Organic Cucumber',
    category: 'vegetable',
    price: 25,
    image: 'https://images.pexels.com/photos/891030/pexels-photo-891030.jpeg',
    unit: 'piece',
    description: 'Cool and crisp cucumbers, perfect for salads.',
    inStock: true,
    isOrganic: true
  },
  {
    id: '12',
    name: 'Fresh Fenugreek',
    category: 'greens',
    price: 25,
    image: 'https://images.pexels.com/photos/2286776/pexels-photo-2286776.jpeg',
    unit: 'bunch',
    description: 'Aromatic fenugreek leaves for curries and breads.',
    inStock: true,
    isOrganic: true
  }
];

export const getProductsByCategory = (category: string) => {
  return products.filter(product => product.category === category);
};

export const getFeaturedProducts = () => {
  return products.filter(product => product.isFeatured);
};

export const getOrganicProducts = () => {
  return products.filter(product => product.isOrganic);
};

export const searchProducts = (query: string) => {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(product => 
    product.name.toLowerCase().includes(lowercaseQuery) || 
    product.description.toLowerCase().includes(lowercaseQuery)
  );
};